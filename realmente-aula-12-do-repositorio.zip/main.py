import math
print( math.factorial(6))
from math import factorial
print(factorial(6))


#------------------trabalhando-com-dicionarios----------------#
classe = {"Ana":4.5,
          "beatriz":6.5,
          "geraldo":1.0,
          "jose":10.0,
          "maria":9.5}
notas = classe.values()
média = sum(notas)/5
print("a média da classe é",média)

dic = {"salgado": 4.50,
       "lanche": 6.60,
       "suco":3.00,
       "refrigerante":3.50,
       "doce":1.00,}
print(dic) 

       
D = {"arroz":17.30,"feijão":12.50,"carne":23.90,"alface":3.40}
print(D)

D["carne"] = 25.0
D["tomate"] = 8.80

print(D)

print('\n')

#-------------praticando-tuplas---------------#
T = (10,20,30,40,50)
a,b,c,d,e = T
print("a = ",a,"b = ",b)

print("d + e = ",d+e)

print('\n')

#-------------praticando-lista------------------#
L = [5,7,2,9,4,1,3]
print("lista = ",L)
print("o tamanho da lista é",len(L))
print("o maior elemento da lisa é",max(L))
print("o menor elemento da lista é",min(L))
print("a soma dos elementos da lista é",sum(L))
L.sort()
print("lista em ordem crescente:",L)
L.reverse()
print("lista em ordem decrescente:",L)
